from django.apps import AppConfig


class TaskConfig(AppConfig):
    name = 'task'
